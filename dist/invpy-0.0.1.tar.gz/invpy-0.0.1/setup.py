# -*- coding: gbk -*-
"""
Created on Wed May 16 13:02:16 2018

@author: mai1346
"""

from setuptools import setup

setup(
  name = 'invpy',
  packages = ['invpy'], 
  version = '0.0.1',
  description = 'An experimental financial data scraper.',
  author = 'Haoyuan Mai',
  author_email = 'maihaoyuan@gmail.com',
  url = 'https://github.com/mai1346/invpy'
#  install_requires= ['requests','pandas','re','beautifulsoup4','numpy']
)

